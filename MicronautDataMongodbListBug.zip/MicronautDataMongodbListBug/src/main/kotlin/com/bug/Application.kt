package com.bug

import io.micronaut.runtime.Micronaut.run
fun main(args: Array<String>) {
	run(*args)
}

